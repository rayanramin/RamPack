#' nin = not in
#' @export

`%nin%` <- Negate(f=`%in%`)
